/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rally.x;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;

public class Protagonista {
	int x = 32;
	int xa = 0;
        int y = 0;
        int ya =0;
	private RallyX game;

	public Protagonista (RallyX game) {
		this.game= game;
	}

	public void move() {
		if (x + xa > 0 && x + xa < game.getWidth()-60)
			x = x + xa;
	}

	public void paint(Graphics2D g) {
             Image img = null;
            try {
               
                
                img=ImageIO.read(new File("C:\\Users\\Guest.Admin-PC\\Desktop\\28003.png"));
            } catch (IOException ex) {
                Logger.getLogger(Protagonista.class.getName()).log(Level.SEVERE, null, ex);
            }
            
             g.drawImage((BufferedImage) img, null, x, 210);
	}

	public void keyReleased(KeyEvent e) {
		xa = 0;
	}

	public void keyPressed(KeyEvent e) {
		if (e.getKeyCode() == KeyEvent.VK_LEFT)
			xa = -4;
		if (e.getKeyCode() == KeyEvent.VK_RIGHT)
			xa = 4;
                if (e.getKeyCode() == KeyEvent.VK_UP)
			ya = -4;
		if (e.getKeyCode() == KeyEvent.VK_DOWN)
			ya = 4;
	}
       
}