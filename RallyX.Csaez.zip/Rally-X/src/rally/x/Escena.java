/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rally.x;

import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;

/**
 *
 * @author Guest
 */
public class Escena {

   

    int[][] arrTiles =      {
        {2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2},
        {2,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,2},
        {2,0,1,1,1,1,1,0,1,0,0,1,1,1,1,1,1,1,1,1,0,1,0,0,0,0,0,0,1,0,0,1,1,1,1,1,1,1,1,0,0,2},
        {2,0,0,0,0,0,1,0,0,0,0,1,0,0,0,0,0,0,0,1,0,1,0,1,1,1,1,0,1,0,0,0,0,0,0,0,0,0,0,0,0,2},
        {2,0,0,0,0,0,1,0,0,1,0,1,0,1,0,0,0,1,0,1,0,1,0,0,0,0,0,0,1,0,0,1,1,1,1,1,1,1,1,0,0,2},
        {2,0,1,1,0,0,0,0,0,1,0,0,0,1,1,1,1,1,0,0,0,1,0,1,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,2},
        {2,0,1,1,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,1,1,0,0,2},
        {2,0,0,0,0,0,1,0,0,1,0,0,0,1,1,1,1,1,0,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,2},
        {2,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,1,1,1,0,0,0,0,1,1,1,1,1,1,1,1,0,0,2},
        {2,0,1,1,1,1,1,0,0,0,0,0,0,1,1,0,0,1,0,1,0,1,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,2},
        {2,0,0,0,0,0,0,0,0,1,1,1,0,1,0,0,0,1,0,1,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,2},
        {2,1,1,1,1,0,0,0,0,1,1,1,0,1,0,0,0,1,0,1,0,1,0,1,1,1,1,0,0,1,1,0,0,0,0,0,0,0,0,0,0,2},
        {2,0,0,0,1,1,1,0,0,0,0,0,0,1,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,1,1,0,0,1,0,1,1,1,1,0,0,2},
        {2,0,0,0,0,0,0,0,0,0,0,0,0,1,1,0,0,1,1,1,0,0,0,0,0,0,0,0,1,1,0,0,0,1,0,0,0,0,1,0,0,2},
        {2,0,0,0,1,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,0,0,0,1,0,1,1,0,1,0,0,2},
        {2,0,1,0,1,1,1,1,1,1,1,1,0,1,0,0,1,1,1,0,1,1,1,0,1,1,1,0,1,0,0,0,0,1,0,1,1,0,1,0,0,2},
        {2,0,1,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,0,1,0,0,0,0,1,0,0,2},
        {2,0,1,1,1,1,1,1,1,1,1,1,1,1,0,0,1,1,1,1,1,0,1,1,1,1,1,1,1,0,0,0,0,1,1,1,1,0,1,0,0,2},
        {2,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,2},
        {2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2}};
   
       

    

    public void inicializar(){
        for (int i = 0; i < this.arrTiles[i].length; i++) {
            for (int j = 0; j < this.arrTiles[j].length; j++) {
                arrTiles[i][j] = 0;
            }
        }
 
    }

    public void paint(Graphics2D g) {
        System.out.println("llamé a paint");
        Image img = null;
        for (int i = 0; i < this.arrTiles.length; i++) {
            for (int j = 0; j < this.arrTiles[i].length; j++) {
                if (arrTiles[i][j] == 1) {
                    System.out.println("estoy imprimiendo");
                     img = impImg ("C:\\Users\\Guest.Admin-PC\\Desktop\\Untitled.jpg");
                }
                   if (arrTiles[i][j] == 2) {
                    System.out.println("estoy imprimiendo");
                     img = impImg ("C:\\Users\\Guest.Admin-PC\\Desktop\\Borde.jpg");     
                   }
                   if (arrTiles[i][j] != 0) {
                   g.drawImage(img, j*img.getHeight(null), i*img.getWidth(null), null);
                    
                    }
                }
                
                    
                }
            }
        
    
    public Image impImg (String s){
        
        Image img = null;
                    try {
                        img = ImageIO.read(new File(s));
                       // g.drawImage(img, j*img.getHeight(null), i*img.getWidth(null), null);
                    } catch (IOException ex) {
                        Logger.getLogger(Escena.class.getName()).log(Level.SEVERE, null, ex);
                    }
    return img;
    }
   
    }
