/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rally.x;

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class RallyX extends JPanel {
@Override
	public void paint(Graphics g) {
		super.paint(g);
		Graphics2D g2d = (Graphics2D) g;
		g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
				RenderingHints.VALUE_ANTIALIAS_ON);
		Escena e = new Escena();
                Protagonista p = new Protagonista(this);
     
        e.paint(g2d);
        p.paint(g2d);
	}
    public static void main(String[] args) {
        JFrame frame = new JFrame("RallyX");
        RallyX game = new RallyX();
        
        frame.add(game);
        frame.setSize(1360, 680);
        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        game.repaint();
        
			



    }
}
